#ifndef STRATEGIES_COMMON_H_
#define STRATEGIES_COMMON_H_

/**
 * \ingroup Optimization
 * \file
 * Common tools strategies.
 */

#include "global.h" // IWYU pragma: keep


#endif //STRATEGIES_COMMON_H_
